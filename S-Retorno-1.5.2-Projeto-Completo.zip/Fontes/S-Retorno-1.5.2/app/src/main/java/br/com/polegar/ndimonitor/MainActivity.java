package br.com.polegar.ndimonitor;

import android.app.Activity;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.provider.Settings;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowInsets;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity implements SurfaceHolder.Callback {
    public static final String PREFERENCES = "ndi_monitor_preferences";
    public static final String KEY_LAST_SOURCE = "last_source";
    public static final String KEY_START_ON_BOOT = "start_on_boot";
    public static final String KEY_DISPLAY_MODE = "display_mode";
    public static final String KEY_HTML_URL = "html_url";
    public static final String KEY_HTML_STAGE_LAYOUT = "html_stage_layout";
    public static final String KEY_HTML_COMPATIBILITY = "html_compatibility";

    // Shared queues preserve connect/cleanup ordering across Activity recreation.
    private static final ExecutorService CAPTURE_WORKER = Executors.newSingleThreadExecutor();
    private static final ExecutorService DISCOVERY_WORKER = Executors.newSingleThreadExecutor();
    private final SourceCatalog sourceCatalog = new SourceCatalog();
    private SharedPreferences preferences;
    private SurfaceView videoSurface;
    private FrameLayout videoContainer;
    private LinearLayout sourcePanel;
    private ListView sourceList;
    private TextView statusText;
    private TextView sourceStatusText;
    private View scanButton;
    private ArrayAdapter<String> sourceAdapter;
    private List<String> displayedSources = Collections.emptyList();
    private AlertDialog settingsDialog;
    private AlertDialog noticesDialog;
    private AlertDialog modeDialog;
    private AlertDialog htmlAddressDialog;
    private AlertDialog htmlLayoutDialog;
    private AlertDialog spresenterDialog;
    private AlertDialog spresenterPairingDialog;
    private SpresenterPairingServer spresenterPairingServer;
    private int spresenterPairingGeneration;
    private HtmlMonitor htmlMonitor;
    private LanHtmlDiscovery htmlDiscovery;
    private LanNetworkMonitor lanNetworkMonitor;
    private final HtmlSourceCatalog htmlSourceCatalog = new HtmlSourceCatalog();
    private List<HtmlSource> displayedHtmlSources = Collections.emptyList();
    private Runnable nextHtmlScan;
    private int htmlScanGeneration;
    private int htmlScanProgress;
    private int htmlScanFound;
    private boolean htmlScanLimited;
    private int htmlApiError;
    private int htmlApiCount;
    private EditText htmlUrlEditor;
    private volatile boolean htmlMode;
    private boolean modeInitialized;
    private boolean ndiAvailable;
    private boolean discoveryRequested;
    private boolean ndiDiscoveryActive;
    private boolean firstNdiDiscovery = true;
    private volatile String currentNdiSource = "";
    private volatile int playbackGeneration;
    private boolean ndiPlaybackRequested;
    private volatile boolean activityVisible;
    private volatile boolean destroyed;
    private volatile int discoveryGeneration;
    private long discoveryStartedAt;
    private Runnable nextDiscoveryPoll;
    private int videoWidth;
    private int videoHeight;
    private WifiManager.MulticastLock multicastLock;
    private AudioTrack audioTrack;
    private int audioSampleRate;
    private int audioChannels;
    private View menuButton;
    private int safeInsetLeft;
    private int safeInsetRight;
    private Object backCallback;
    private LocalControl localControl;
    private final ReceiverStats receiverStats = new ReceiverStats();
    private double sourceFps;
    private final Handler controlsHandler = new Handler(Looper.getMainLooper());
    private final Runnable hideControls = () -> {
        if (sourcePanel.getVisibility() != View.VISIBLE) {
            menuButton.setVisibility(View.GONE);
            statusText.setVisibility(View.GONE);
            enterImmersiveMode();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        enterImmersiveMode();
        setContentView(R.layout.activity_main);

        preferences = getSharedPreferences(PREFERENCES, MODE_PRIVATE);
        videoContainer = findViewById(R.id.video_container);
        videoSurface = findViewById(R.id.video_surface);
        sourcePanel = findViewById(R.id.source_panel);
        sourceList = findViewById(R.id.source_list);
        statusText = findViewById(R.id.status_text);
        sourceStatusText = findViewById(R.id.source_status_text);
        scanButton = findViewById(R.id.scan_button);
        htmlDiscovery = new LanHtmlDiscovery(this);
        htmlSourceCatalog.remember(preferences.getString(KEY_HTML_URL, ""), SystemClock.elapsedRealtime());
        try { applyLocalCatalog(new org.json.JSONObject(preferences.getString("local_html_catalog", "{}")), false); }
        catch (Exception invalid) { /* Ignore a missing or obsolete saved catalog. */ }
        htmlMonitor = new HtmlMonitor(this, findViewById(R.id.html_container), new HtmlMonitor.Listener() {
            @Override public void onStatus(int message) {
                if (!destroyed && htmlMode) {
                    statusText.setText(message);
                    if (localControl != null && message == R.string.html_renderer_unavailable)
                        localControl.store.event("html_renderer_failure");
                }
            }

            @Override public void onInteraction() { showControls(); }
        });
        htmlMonitor.setDisplayLayout(preferences.getBoolean(KEY_HTML_STAGE_LAYOUT, true),
                preferences.getBoolean(KEY_HTML_COMPATIBILITY, Build.VERSION.SDK_INT <= 25));
        localControl = new LocalControl(this, new LocalControl.Host() {
            @Override public org.json.JSONObject status() throws Exception { return localStatus(); }
            @Override public org.json.JSONObject sources() throws Exception { return localSources(); }
            @Override public org.json.JSONObject command(org.json.JSONObject command) throws Exception { return localCommand(command); }
        });
        sourceAdapter = new ArrayAdapter<>(this, R.layout.source_item, new ArrayList<>());
        sourceList.setAdapter(sourceAdapter);
        sourceList.setOnItemClickListener((parent, view, position, id) -> {
            if (htmlMode) {
                if (position < displayedHtmlSources.size()) selectHtmlSource(displayedHtmlSources.get(position).url);
            } else {
                String source = sourceAdapter.getItem(position);
                if (source != null) connectToSource(source);
            }
        });

        View root = findViewById(R.id.root);
        root.addOnLayoutChangeListener((view, left, top, right, bottom,
                                       oldLeft, oldTop, oldRight, oldBottom) -> {
            if (right - left != oldRight - oldLeft || bottom - top != oldBottom - oldTop) {
                resizeSourcePanel(right - left);
                fitVideoSurface(videoWidth, videoHeight);
            }
        });
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            applyControlInsets(insets);
            resizeSourcePanel(view.getWidth());
            return insets;
        });

        videoSurface.getHolder().addCallback(this);
        menuButton = findViewById(R.id.menu_button);
        videoSurface.setOnClickListener(v -> showControls());
        videoContainer.setOnClickListener(v -> showControls());
        menuButton.setOnClickListener(v -> toggleSourcePanel());
        findViewById(R.id.close_panel_button).setOnClickListener(v -> closeSourcePanel());
        scanButton.setOnClickListener(v -> {
            discoveryRequested = true;
            scanSources();
        });
        findViewById(R.id.source_mode_button).setOnClickListener(v -> showModeChooser());
        findViewById(R.id.manual_html_button).setOnClickListener(v -> showHtmlAddress());
        findViewById(R.id.reload_html_button).setOnClickListener(v -> htmlMonitor.reload());
        findViewById(R.id.monitor_settings_button).setOnClickListener(v -> showMonitorSettings());
        menuButton.setVisibility(View.GONE);
        statusText.setVisibility(View.GONE);
        backCallback = BackNavigation.register(this, this::toggleSourcePanel);
        root.requestApplyInsets();

        WifiManager wifiManager = (WifiManager) getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);
        if (wifiManager != null) {
            multicastLock = wifiManager.createMulticastLock("NDIMonitorDiscovery");
            multicastLock.setReferenceCounted(false);
        }

        NdiReceiver.setCallbackTarget(this);
        boolean validHtml = HtmlSourceUrl.isWebAddress(preferences.getString(KEY_HTML_URL, ""));
        String savedNdi = preferences.getString(KEY_LAST_SOURCE, "");
        boolean validNdi = savedNdi != null && !savedNdi.trim().isEmpty();
        boolean htmlOnly = getIntent().getBooleanExtra(StartupActivity.EXTRA_HTML_ONLY, false);
        String savedMode = preferences.getString(KEY_DISPLAY_MODE, "");
        // First use on old TV firmware opens HTML without loading any NDI code.
        // A previously selected NDI source still restores normally.
        boolean savedHtml = htmlOnly || Build.VERSION.SDK_INT < 24
                || "html".equals(savedMode)
                || (Build.VERSION.SDK_INT <= 25 && savedMode.isEmpty() && !validNdi);
        // Older versions saved a browsed mode before a source was selected.
        if (!htmlOnly && Build.VERSION.SDK_INT >= 24 && savedHtml && !validHtml && validNdi) savedHtml = false;
        else if (!savedHtml && !validNdi && validHtml) savedHtml = true;
        setSourceMode(savedHtml, true);
        lanNetworkMonitor = new LanNetworkMonitor(this, () -> {
            if (htmlMode && activityVisible && !destroyed) {
                if (discoveryRequested) scanSources();
                else scanHtmlSources(true);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        activityVisible = true;
        if (localControl != null) localControl.foreground();
        updateMulticastLock();
        htmlMonitor.resume();
        if (!htmlMode && ndiAvailable && !currentNdiSource.isEmpty()) startNdiPlayback();
        scanSources();
        if (lanNetworkMonitor != null) lanNetworkMonitor.start();
        StartupJournal.get(this).finishStartup();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // A Home/launcher redirect can deliver onNewIntent to the existing task
        // without another onStart; it must not leave a false pending startup.
        StartupJournal.get(this).finishStartup();
    }

    @Override
    protected void onStop() {
        activityVisible = false;
        if (lanNetworkMonitor != null) lanNetworkMonitor.stop();
        if (localControl != null) localControl.background();
        stopSpresenterPairing();
        htmlMonitor.pause();
        stopNdiPlayback();
        releaseAudio();
        stopDiscoveryPolling();
        if (multicastLock != null && multicastLock.isHeld()) multicastLock.release();
        super.onStop();
    }

    private void updateMulticastLock() {
        if (multicastLock == null) return;
        if (ndiAvailable && activityVisible && !htmlMode &&
                (ndiDiscoveryActive || !currentNdiSource.isEmpty())) {
            if (!multicastLock.isHeld()) multicastLock.acquire();
        } else if (multicastLock.isHeld()) {
            multicastLock.release();
        }
    }

    private void showModeChooser() {
        if (modeDialog != null && modeDialog.isShowing()) return;
        stopDiscoveryPolling();
        modeDialog = new AlertDialog.Builder(this)
                .setTitle(R.string.choose_mode)
                .setSingleChoiceItems(R.array.monitor_modes, htmlMode ? 1 : 0, (dialog, which) -> {
                    setSourceMode(which == 1, false);
                    dialog.dismiss();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .create();
        modeDialog.setOnDismissListener(dialog -> {
            modeDialog = null;
            if (!destroyed) scanSources();
        });
        modeDialog.show();
    }

    private void setSourceMode(boolean html, boolean restoring) {
        if (modeInitialized && htmlMode == html) return;
        modeInitialized = true;
        htmlMode = html;
        if (!html) {
            StartupJournal journal = StartupJournal.get(this);
            long operation = journal.beginOperation("Inicializando o receptor NDI");
            try { ndiAvailable = NdiReceiver.isNdiAvailable(); }
            finally { journal.finishOperation(operation); }
        }
        discoveryRequested = false;
        ((TextView) findViewById(R.id.source_mode_button)).setText(html ? R.string.mode_html : R.string.mode_ndi);
        sourceList.setVisibility(View.VISIBLE);
        findViewById(R.id.html_actions).setVisibility(html ? View.VISIBLE : View.GONE);
        sourceStatusText.setMaxLines(html ? 1 : 2);
        scanButton.setContentDescription(getString(html ? R.string.search_html : R.string.refresh_sources));
        scanButton.setEnabled(html || ndiAvailable);
        stopDiscoveryPolling();
        updateMulticastLock();
        if (html) {
            stopNdiPlayback();
            releaseAudio();
            currentNdiSource = "";
            videoSurface.setVisibility(View.GONE);
            showHtmlSources();
            String address = preferences.getString(KEY_HTML_URL, "");
            if (!HtmlSourceUrl.isWebAddress(address)) address = "";
            if (!address.isEmpty()) {
                if (restoring) {
                    htmlMonitor.show(address);
                    closeSourcePanel();
                } else selectHtmlSource(address);
            } else {
                htmlMonitor.show("");
                sourcePanel.setVisibility(View.VISIBLE);
                discoveryRequested = true;
                sourceStatusText.setText(R.string.searching_html);
                scanSources();
            }
        } else {
            displayedHtmlSources = Collections.emptyList();
            sourceAdapter.clear();
            displayedSources = Collections.emptyList();
            htmlMonitor.hide();
            videoSurface.setVisibility(View.VISIBLE);
            String lastSource = preferences.getString(KEY_LAST_SOURCE, "");
            currentNdiSource = lastSource == null || lastSource.trim().isEmpty() ? "" : lastSource;
            if (!ndiAvailable) {
                sourceStatusText.setText(R.string.ndi_sdk_missing);
                sourcePanel.setVisibility(View.VISIBLE);
                return;
            }
            if (!currentNdiSource.isEmpty()) {
                sourceCatalog.update(new String[]{currentNdiSource}, SystemClock.elapsedRealtime());
                showSources(Collections.singletonList(currentNdiSource));
                sourceStatusText.setText(R.string.discovery_idle);
                if (restoring) {
                    statusText.setText(getString(R.string.connecting_to, currentNdiSource));
                    closeSourcePanel();
                } else connectToSource(currentNdiSource);
            } else {
                sourcePanel.setVisibility(View.VISIBLE);
                discoveryRequested = true;
                sourceStatusText.setText(R.string.searching_sources);
                scanSources();
            }
        }
        int nextFocus = R.id.source_list;
        for (int id : new int[]{R.id.source_mode_button, R.id.scan_button,
                R.id.monitor_settings_button, R.id.close_panel_button}) {
            findViewById(id).setNextFocusDownId(nextFocus);
        }
    }

    private void openHtmlSource() {
        if (!htmlMode) return;
        String address;
        try {
            address = HtmlSourceUrl.normalize(htmlUrlEditor.getText().toString());
        } catch (IllegalArgumentException invalid) {
            htmlUrlEditor.setError(getString(R.string.html_invalid_address));
            htmlUrlEditor.requestFocus();
            return;
        }
        htmlUrlEditor.setError(null);
        htmlUrlEditor.setText(address);
        InputMethodManager keyboard = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (keyboard != null) keyboard.hideSoftInputFromWindow(htmlUrlEditor.getWindowToken(), 0);
        selectHtmlSource(address);
        if (htmlAddressDialog != null) htmlAddressDialog.dismiss();
    }

    private void selectHtmlSource(String address) {
        if (!htmlMode || !HtmlSourceUrl.isWebAddress(address)) return;
        preferences.edit().putString(KEY_DISPLAY_MODE, "html").putString(KEY_HTML_URL, address).apply();
        htmlSourceCatalog.remember(address, SystemClock.elapsedRealtime());
        htmlMonitor.show(address);
        closeSourcePanel();
        showControls();
    }

    private void showHtmlAddress() {
        if (!htmlMode || (htmlAddressDialog != null && htmlAddressDialog.isShowing())) return;
        stopDiscoveryPolling();
        View form = getLayoutInflater().inflate(R.layout.dialog_html_address, null);
        htmlUrlEditor = form.findViewById(R.id.html_url);
        htmlUrlEditor.setText(preferences.getString(KEY_HTML_URL, ""));
        form.findViewById(R.id.open_html_button).setOnClickListener(v -> openHtmlSource());
        htmlUrlEditor.setOnEditorActionListener((view, action, event) -> {
            if (action != EditorInfo.IME_ACTION_GO) return false;
            openHtmlSource();
            return true;
        });
        htmlAddressDialog = new AlertDialog.Builder(this).setTitle(R.string.html_address)
                .setView(form).setNegativeButton(android.R.string.cancel, null).create();
        htmlAddressDialog.setOnDismissListener(dialog -> {
            htmlAddressDialog = null;
            if (!destroyed) scanSources();
        });
        htmlAddressDialog.show();
    }

    private void scanHtmlSources() {
        scanHtmlSources(false);
    }

    private void scanHtmlSources(boolean publicOnly) {
        stopDiscoveryPolling();
        int generation = htmlScanGeneration;
        htmlScanProgress = 0;
        htmlScanFound = 0;
        htmlApiError = 0;
        htmlApiCount = -1;
        showHtmlSources();
        sourceStatusText.setText(R.string.searching_html);
        LanHtmlDiscovery.Listener listener = new LanHtmlDiscovery.Listener() {
            private boolean current() {
                return htmlMode && !destroyed && activityVisible && generation == htmlScanGeneration;
            }
            @Override public void onStarted(int total, boolean limited) {
                if (!current()) return;
                htmlScanLimited = limited;
                sourceStatusText.setText(getString(R.string.html_scan_progress, 0, total));
            }
            @Override public void onSource(HtmlSource source) {
                if (!current()) return;
                ++htmlScanFound;
                htmlSourceCatalog.found(source, SystemClock.elapsedRealtime());
                showHtmlSources();
            }
            @Override public void onProgress(int done, int total) {
                if (!current()) return;
                htmlScanProgress = Math.max(htmlScanProgress, done);
                sourceStatusText.setText(getString(R.string.html_scan_progress, htmlScanProgress, total));
            }
            @Override public void onCatalog(String origin, List<HtmlSource> sources) {
                if (!current()) return;
                htmlApiCount = sources.size();
                htmlScanFound += sources.size();
                htmlSourceCatalog.replaceFromCatalog(origin, sources, SystemClock.elapsedRealtime());
                showHtmlSources();
            }
            @Override public void onCatalogError(int message) {
                if (!current()) return;
                htmlApiError = message;
                sourceStatusText.setText(message);
            }
            @Override public void onFinished() {
                if (!current()) return;
                htmlSourceCatalog.finishScan(SystemClock.elapsedRealtime());
                showHtmlSources();
                if (htmlApiError != 0) sourceStatusText.setText(htmlApiError);
                else if (htmlApiCount >= 0) sourceStatusText.setText(getString(R.string.spresenter_api_found, displayedHtmlSources.size()));
                else sourceStatusText.setText(htmlScanFound == 0 ? R.string.html_none_found :
                            htmlScanLimited ? R.string.html_found_limited : R.string.html_found);
                if (!publicOnly) scheduleNextHtmlScan(generation);
            }
            @Override public void onUnavailable() {
                if (!current()) return;
                sourceStatusText.setText(R.string.html_no_lan);
                if (!publicOnly) scheduleNextHtmlScan(generation);
            }
        };
        String saved = preferences.getString(KEY_HTML_URL, "");
        if (publicOnly) htmlDiscovery.startPublic(saved, listener);
        else htmlDiscovery.start(saved, listener);
    }

    private void scheduleNextHtmlScan(int generation) {
        nextHtmlScan = () -> {
            if (generation == htmlScanGeneration) scanSources();
        };
        controlsHandler.postDelayed(nextHtmlScan, 30_000);
    }

    private void showHtmlSources() {
        List<HtmlSource> next = htmlSourceCatalog.snapshot();
        List<String> labels = new ArrayList<>();
        for (HtmlSource source : next) labels.add(source.displayName());
        if (displayedSources.equals(labels)) { displayedHtmlSources = next; return; }
        int first = sourceList.getFirstVisiblePosition();
        View child = sourceList.getChildAt(0);
        int top = child == null ? 0 : child.getTop();
        int selection = sourceList.getSelectedItemPosition();
        String selectedUrl = selection >= 0 && selection < displayedHtmlSources.size()
                ? displayedHtmlSources.get(selection).url : null;
        sourceAdapter.setNotifyOnChange(false);
        sourceAdapter.clear();
        sourceAdapter.addAll(labels);
        sourceAdapter.notifyDataSetChanged();
        displayedSources = labels;
        displayedHtmlSources = next;
        int nextSelection = -1;
        for (int i = 0; i < next.size(); ++i) {
            if (next.get(i).url.equals(selectedUrl)) { nextSelection = i; break; }
        }
        if (nextSelection >= 0) sourceList.setSelection(nextSelection);
        else if (!labels.isEmpty()) sourceList.setSelectionFromTop(Math.min(first, labels.size() - 1), top);
    }

    private void resizeSourcePanel(int availableWidth) {
        availableWidth -= safeInsetLeft + safeInsetRight;
        if (availableWidth <= 0) return;
        int maximumWidth = getResources().getDimensionPixelSize(R.dimen.source_panel_width);
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) sourcePanel.getLayoutParams();
        int width = Math.min(availableWidth, maximumWidth);
        if (params.width != width) {
            params.width = width;
            sourcePanel.setLayoutParams(params);
        }
    }

    private void applyControlInsets(WindowInsets insets) {
        int[] safe = ControlInsets.read(insets);
        int left = safe[0], top = safe[1], right = safe[2], bottom = safe[3];
        safeInsetLeft = left;
        safeInsetRight = right;
        FrameLayout.LayoutParams panel = (FrameLayout.LayoutParams) sourcePanel.getLayoutParams();
        panel.setMargins(left, top, right, bottom);
        sourcePanel.setLayoutParams(panel);
        int margin = getResources().getDimensionPixelSize(R.dimen.overlay_margin);
        FrameLayout.LayoutParams menu = (FrameLayout.LayoutParams) menuButton.getLayoutParams();
        menu.setMargins(margin + left, margin + top, margin + right, margin + bottom);
        menuButton.setLayoutParams(menu);
        FrameLayout.LayoutParams status = (FrameLayout.LayoutParams) statusText.getLayoutParams();
        status.setMargins(margin + left, margin + top, margin + right, margin + bottom);
        statusText.setLayoutParams(status);
    }

    private void showMonitorSettings() {
        if (settingsDialog != null && settingsDialog.isShowing()) return;
        stopDiscoveryPolling();
        View content = getLayoutInflater().inflate(R.layout.dialog_monitor_settings, null);
        CheckBox bootCheckBox = content.findViewById(R.id.boot_checkbox);
        bootCheckBox.setChecked(preferences.getBoolean(KEY_START_ON_BOOT, true));
        bootCheckBox.setOnCheckedChangeListener((button, checked) ->
                preferences.edit().putBoolean(KEY_START_ON_BOOT, checked).apply());
        settingsDialog = new AlertDialog.Builder(this)
                .setTitle(R.string.monitor_settings)
                .setView(content)
                .setPositiveButton(R.string.close, null)
                .create();
        content.findViewById(R.id.home_settings_button).setOnClickListener(v -> {
            settingsDialog.dismiss();
            openAndroidSettings(Settings.ACTION_HOME_SETTINGS);
        });
        content.findViewById(R.id.android_settings_button).setOnClickListener(v -> {
            settingsDialog.dismiss();
            openAndroidSettings(Settings.ACTION_SETTINGS);
        });
        content.findViewById(R.id.third_party_notices_button).setOnClickListener(v ->
                showThirdPartyNotices());
        content.findViewById(R.id.local_control_button).setOnClickListener(v -> localControl.show());
        View apiButton = content.findViewById(R.id.spresenter_api_button);
        apiButton.setVisibility(htmlMode ? View.VISIBLE : View.GONE);
        apiButton.setOnClickListener(v -> showSpresenterConnection());
        TextView layoutButton = content.findViewById(R.id.html_layout_button);
        layoutButton.setVisibility(htmlMode ? View.VISIBLE : View.GONE);
        updateHtmlLayoutButton(layoutButton);
        layoutButton.setOnClickListener(v -> {
            if (htmlLayoutDialog != null && htmlLayoutDialog.isShowing()) return;
            htmlLayoutDialog = new AlertDialog.Builder(this)
                    .setTitle(R.string.html_layout_title)
                    .setSingleChoiceItems(R.array.html_layouts,
                            !preferences.getBoolean(KEY_HTML_STAGE_LAYOUT, true) ? 1
                                    : preferences.getBoolean(KEY_HTML_COMPATIBILITY, Build.VERSION.SDK_INT <= 25) ? 2 : 0,
                            (dialog, which) -> {
                                boolean stage = which != 1;
                                boolean compatibility = which == 2;
                                preferences.edit().putBoolean(KEY_HTML_STAGE_LAYOUT, stage)
                                        .putBoolean(KEY_HTML_COMPATIBILITY, compatibility).apply();
                                htmlMonitor.setDisplayLayout(stage, compatibility);
                                updateHtmlLayoutButton(layoutButton);
                                dialog.dismiss();
                            }).setNegativeButton(android.R.string.cancel, null).create();
            htmlLayoutDialog.setOnDismissListener(dialog -> htmlLayoutDialog = null);
            htmlLayoutDialog.show();
        });
        settingsDialog.setOnDismissListener(dialog -> {
            settingsDialog = null;
            if (!destroyed) scanSources();
        });
        settingsDialog.show();
    }

    private void showSpresenterConnection() {
        if (spresenterDialog != null && spresenterDialog.isShowing()) return;
        stopDiscoveryPolling();
        SpresenterApiSettings api = new SpresenterApiSettings(this);
        View form = getLayoutInflater().inflate(R.layout.dialog_spresenter_api, null);
        EditText address = form.findViewById(R.id.spresenter_api_address);
        EditText token = form.findViewById(R.id.spresenter_api_token);
        EditText link = form.findViewById(R.id.spresenter_editor_link);
        String initial = api.origin();
        if (initial.isEmpty()) {
            try {
                java.net.URI saved = java.net.URI.create(preferences.getString(KEY_HTML_URL, ""));
                initial = new java.net.URI(saved.getScheme(), null, saved.getHost(), saved.getPort(),
                        "", null, null).toASCIIString();
            } catch (Exception ignored) { initial = ""; }
        }
        address.setText(initial);
        spresenterDialog = new AlertDialog.Builder(this).setTitle(R.string.spresenter_api_title)
                .setView(form).setNegativeButton(android.R.string.cancel, null).create();
        form.findViewById(R.id.spresenter_pairing_button).setOnClickListener(v -> showSpresenterPairing());
        form.findViewById(R.id.spresenter_link_save).setOnClickListener(v -> {
            try { saveSpresenterConnection(SpresenterConnection.fromEditorLink(link.getText().toString())); }
            catch (IllegalArgumentException invalid) { link.setError(getString(R.string.spresenter_editor_link_invalid)); }
        });
        form.findViewById(R.id.spresenter_manual_button).setOnClickListener(v -> {
            View manual = form.findViewById(R.id.spresenter_manual_form);
            manual.setVisibility(manual.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
        });
        form.findViewById(R.id.spresenter_api_save).setOnClickListener(v -> {
            String origin;
            try { origin = SpresenterConnection.normalizeOrigin(address.getText().toString()); }
            catch (IllegalArgumentException invalid) { address.setError(getString(R.string.spresenter_api_bad_address)); return; }
            String key = token.getText().toString().trim();
            SpresenterConnection previous = api.load(origin);
            if (key.isEmpty() && previous != null && previous.origin.equals(origin)) key = previous.token;
            SpresenterConnection connection;
            try { connection = new SpresenterConnection(origin, key); }
            catch (IllegalArgumentException invalid) { token.setError(getString(R.string.spresenter_api_key_required)); return; }
            saveSpresenterConnection(connection);
        });
        android.widget.LinearLayout pcs = form.findViewById(R.id.spresenter_pc_list);
        for (String origin : api.origins()) {
            android.widget.LinearLayout row = new android.widget.LinearLayout(this);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            TextView name = new TextView(this);
            name.setText(origin);
            row.addView(name, new android.widget.LinearLayout.LayoutParams(0, -2, 1));
            android.widget.Button remove = new android.widget.Button(this);
            remove.setText(R.string.spresenter_remove_pc);
            remove.setAllCaps(false);
            remove.setContentDescription(getString(R.string.spresenter_remove_pc_description, origin));
            if (origin.equals(api.origin())) remove.setId(R.id.spresenter_api_remove);
            remove.setOnClickListener(v -> {
                api.remove(origin);
                htmlSourceCatalog.forgetDirectCatalog(origin, SystemClock.elapsedRealtime());
                startCatalogSearch();
            });
            row.addView(remove);
            pcs.addView(row);
        }
        pcs.setVisibility(api.origins().isEmpty() ? View.GONE : View.VISIBLE);
        EditText extraPrefix = form.findViewById(R.id.html_search_prefix);
        extraPrefix.setText(preferences.getString(HtmlSearchSettings.EXTRA_PREFIX, ""));
        form.findViewById(R.id.html_search_range_toggle).setOnClickListener(v -> {
            View range = form.findViewById(R.id.html_search_range_form);
            range.setVisibility(range.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
        });
        form.findViewById(R.id.html_search_range_save).setOnClickListener(v -> {
            try {
                String prefix = HtmlSearchSettings.normalize(extraPrefix.getText().toString());
                if (prefix.isEmpty()) preferences.edit().remove(HtmlSearchSettings.EXTRA_PREFIX).apply();
                else preferences.edit().putString(HtmlSearchSettings.EXTRA_PREFIX, prefix).apply();
                startCatalogSearch();
            } catch (IllegalArgumentException invalid) { extraPrefix.setError(getString(R.string.html_search_range_invalid)); }
        });
        spresenterDialog.setOnDismissListener(dialog -> {
            if (spresenterDialog != dialog) return;
            stopSpresenterPairing();
            link.setText("");
            token.setText("");
            spresenterDialog = null;
        });
        spresenterDialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        spresenterDialog.show();
        form.findViewById(R.id.spresenter_pairing_button).requestFocus();
    }

    private void saveSpresenterConnection(SpresenterConnection connection) {
        SpresenterApiSettings api = new SpresenterApiSettings(this);
        boolean durable;
        try { durable = api.save(connection); }
        catch (IllegalArgumentException full) {
            android.widget.Toast.makeText(this, getString(R.string.spresenter_api_limit, SpresenterApiSettings.MAX_CONNECTIONS),
                    android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        if (!durable) android.widget.Toast.makeText(this, R.string.spresenter_api_session,
                android.widget.Toast.LENGTH_LONG).show();
        stopSpresenterPairing();
        startCatalogSearch();
    }

    private void showSpresenterPairing() {
        if (destroyed || !activityVisible || !htmlMode ||
                (spresenterPairingDialog != null && spresenterPairingDialog.isShowing())) return;
        stopSpresenterPairing();
        String address = SpresenterSetupNetwork.address(this);
        if (address == null) {
            android.widget.Toast.makeText(this, R.string.spresenter_pairing_no_network,
                    android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        int generation = ++spresenterPairingGeneration;
        try {
            spresenterPairingServer = new SpresenterPairingServer(address, new SpresenterPairingServer.Listener() {
                @Override public void onConnection(SpresenterConnection connection) {
                    controlsHandler.post(() -> {
                        if (isSpresenterPairingActive(generation)) saveSpresenterConnection(connection);
                    });
                }
                @Override public void onEnded() {
                    controlsHandler.post(() -> {
                        if (!isSpresenterPairingActive(generation)) return;
                        stopSpresenterPairing();
                        android.widget.Toast.makeText(MainActivity.this, R.string.spresenter_pairing_ended,
                                android.widget.Toast.LENGTH_LONG).show();
                    });
                }
            });
            View pairing = getLayoutInflater().inflate(R.layout.dialog_spresenter_pairing, null);
            ((TextView) pairing.findViewById(R.id.spresenter_pairing_address)).setText(spresenterPairingServer.address());
            ((TextView) pairing.findViewById(R.id.spresenter_pairing_code)).setText(spresenterPairingServer.code());
            spresenterPairingDialog = new AlertDialog.Builder(this).setTitle(R.string.spresenter_pairing_title)
                    .setView(pairing).setNegativeButton(R.string.close, null).create();
            spresenterPairingDialog.setOnDismissListener(dialog -> {
                if (spresenterPairingDialog == dialog) stopSpresenterPairing();
            });
            spresenterPairingDialog.show();
            spresenterPairingServer.start();
        } catch (IOException | RuntimeException unavailable) {
            stopSpresenterPairing();
            android.widget.Toast.makeText(this, R.string.spresenter_pairing_unavailable,
                    android.widget.Toast.LENGTH_LONG).show();
        }
    }

    private boolean isSpresenterPairingActive(int generation) {
        return !destroyed && activityVisible && htmlMode && generation == spresenterPairingGeneration &&
                spresenterPairingServer != null && spresenterPairingDialog != null &&
                spresenterPairingDialog.isShowing();
    }

    private void stopSpresenterPairing() {
        ++spresenterPairingGeneration;
        SpresenterPairingServer server = spresenterPairingServer;
        spresenterPairingServer = null;
        if (server != null) server.close();
        AlertDialog dialog = spresenterPairingDialog;
        spresenterPairingDialog = null;
        if (dialog != null) dialog.dismiss();
    }

    private void startCatalogSearch() {
        discoveryRequested = true;
        sourcePanel.setVisibility(View.VISIBLE);
        if (spresenterDialog != null) spresenterDialog.dismiss();
        if (settingsDialog != null) settingsDialog.dismiss();
        else scanSources();
    }

    private void updateHtmlLayoutButton(TextView button) {
        button.setText(getString(R.string.html_layout_button, getString(
                !preferences.getBoolean(KEY_HTML_STAGE_LAYOUT, true) ? R.string.html_layout_page
                        : preferences.getBoolean(KEY_HTML_COMPATIBILITY, Build.VERSION.SDK_INT <= 25)
                                ? R.string.html_layout_compatibility : R.string.html_layout_monitor)));
    }

    private void showThirdPartyNotices() {
        if (noticesDialog != null && noticesDialog.isShowing()) return;
        String notices;
        try (InputStream input = getAssets().open("libndi_licenses.txt");
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            notices = new String(output.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException unavailable) {
            notices = getString(R.string.third_party_notices_unavailable);
        }
        noticesDialog = new AlertDialog.Builder(this)
                .setTitle(R.string.third_party_notices)
                .setMessage(notices)
                .setPositiveButton(android.R.string.ok, null)
                .create();
        noticesDialog.setOnDismissListener(dialog -> noticesDialog = null);
        noticesDialog.show();
    }

    private void enterImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private void openAndroidSettings(String action) {
        try {
            startActivity(new Intent(action));
        } catch (ActivityNotFoundException unavailable) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (ActivityNotFoundException ignored) {
                android.widget.Toast.makeText(this,
                        "Configurações indisponíveis neste aparelho", android.widget.Toast.LENGTH_LONG).show();
            }
        }
    }

    private void toggleSourcePanel() {
        if (sourcePanel.getVisibility() == View.VISIBLE) {
            closeSourcePanel();
        } else {
            controlsHandler.removeCallbacks(hideControls);
            sourcePanel.setVisibility(View.VISIBLE);
            menuButton.setVisibility(View.GONE);
            statusText.setVisibility(View.GONE);
            if (!hasSavedSource()) discoveryRequested = true;
            if (!discoveryRequested && (htmlMode || ndiAvailable)) {
                sourceStatusText.setText(R.string.discovery_idle);
            }
            if (htmlMode && !discoveryRequested) scanHtmlSources(true);
            else scanSources();
            if (!displayedSources.isEmpty()) sourceList.requestFocus();
            else if (htmlMode) findViewById(R.id.manual_html_button).requestFocus();
        }
    }

    private void closeSourcePanel() {
        discoveryRequested = false;
        stopDiscoveryPolling();
        sourcePanel.setVisibility(View.GONE);
        hideControls.run();
    }

    private void showControls() {
        if (sourcePanel.getVisibility() == View.VISIBLE) return;
        menuButton.setVisibility(View.VISIBLE);
        statusText.setVisibility(View.VISIBLE);
        controlsHandler.removeCallbacks(hideControls);
        controlsHandler.postDelayed(hideControls, 4000);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int keyCode = event.getKeyCode();
        if (event.getAction() == KeyEvent.ACTION_DOWN && sourcePanel.getVisibility() != View.VISIBLE &&
                (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER ||
                 keyCode == KeyEvent.KEYCODE_MENU)) {
            if (event.getRepeatCount() > 0) return true;
            if (menuButton.getVisibility() == View.VISIBLE) {
                toggleSourcePanel();
            } else {
                showControls();
                menuButton.requestFocus();
            }
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    // Legacy fallback. API 33+ registers OnBackInvokedDispatcher in onCreate.
    @SuppressLint("GestureBackNavigation")
    public void onBackPressed() {
        toggleSourcePanel();
    }

    private void scanSources() {
        if (!discoveryRequested || (!htmlMode && !ndiAvailable) || !activityVisible || destroyed ||
                sourcePanel.getVisibility() != View.VISIBLE ||
                (modeDialog != null && modeDialog.isShowing()) ||
                (htmlAddressDialog != null && htmlAddressDialog.isShowing()) ||
                (spresenterDialog != null && spresenterDialog.isShowing()) ||
                (spresenterPairingDialog != null && spresenterPairingDialog.isShowing()) ||
                (settingsDialog != null && settingsDialog.isShowing())) return;
        if (htmlMode) { scanHtmlSources(); return; }
        stopDiscoveryPolling();
        discoveryStartedAt = SystemClock.elapsedRealtime();
        ndiDiscoveryActive = true;
        updateMulticastLock();
        sourceCatalog.beginRefresh(discoveryStartedAt);
        if (displayedSources.isEmpty()) sourceStatusText.setText(R.string.searching_sources);
        // Show sources already known to the live finder before waiting for updates.
        pollDiscovery(discoveryGeneration, 0);
    }

    private void stopDiscoveryPolling() {
        ++discoveryGeneration;
        ++htmlScanGeneration;
        if (htmlDiscovery != null) htmlDiscovery.stop();
        if (nextHtmlScan != null) {
            controlsHandler.removeCallbacks(nextHtmlScan);
            nextHtmlScan = null;
        }
        if (nextDiscoveryPoll != null) {
            controlsHandler.removeCallbacks(nextDiscoveryPoll);
            nextDiscoveryPoll = null;
        }
        if (ndiDiscoveryActive) {
            ndiDiscoveryActive = false;
            DISCOVERY_WORKER.execute(NdiReceiver::releaseDiscovery);
        }
        updateMulticastLock();
    }

    private void pollDiscovery(int generation, int timeoutMs) {
        if (destroyed || !activityVisible || !discoveryRequested || !ndiDiscoveryActive ||
                htmlMode || generation != discoveryGeneration) return;
        DISCOVERY_WORKER.execute(() -> {
            if (destroyed || generation != discoveryGeneration) return;
            StartupJournal journal = StartupJournal.get(this);
            long operation = firstNdiDiscovery ? journal.beginOperation("Primeira busca de fontes NDI") : 0;
            firstNdiDiscovery = false;
            String[] result;
            try { result = NdiReceiver.findSources(timeoutMs); }
            finally { if (operation != 0) journal.finishOperation(operation); }
            controlsHandler.post(() -> {
                if (destroyed || !activityVisible || generation != discoveryGeneration ||
                        sourcePanel.getVisibility() != View.VISIBLE) return;
                showSources(sourceCatalog.update(result, SystemClock.elapsedRealtime()));
                nextDiscoveryPoll = () -> pollDiscovery(generation, 500);
                controlsHandler.postDelayed(nextDiscoveryPoll, 50);
            });
        });
    }

    private void showSources(List<String> sources) {
        if (!displayedSources.equals(sources)) {
            String selected = (String) sourceList.getSelectedItem();
            int first = sourceList.getFirstVisiblePosition();
            View firstChild = sourceList.getChildAt(0);
            int top = firstChild == null ? 0 : firstChild.getTop();
            sourceAdapter.setNotifyOnChange(false);
            sourceAdapter.clear();
            sourceAdapter.addAll(sources);
            sourceAdapter.notifyDataSetChanged();
            displayedSources = new ArrayList<>(sources);
            int selection = selected == null ? -1 : sourceAdapter.getPosition(selected);
            if (selection >= 0) {
                sourceList.setSelection(selection);
            } else if (!sources.isEmpty()) {
                sourceList.setSelectionFromTop(Math.min(first, sources.size() - 1), top);
            }
        }
        String message = sources.isEmpty()
                ? getString(SystemClock.elapsedRealtime() - discoveryStartedAt < 5000
                        ? R.string.searching_sources : R.string.no_sources)
                : getResources().getQuantityString(R.plurals.sources_found, sources.size(), sources.size());
        if (!TextUtils.equals(sourceStatusText.getText(), message)) sourceStatusText.setText(message);
    }

    private void connectToSource(String sourceName) {
        if (htmlMode || sourceName == null || sourceName.trim().isEmpty()) return;
        preferences.edit().putString(KEY_DISPLAY_MODE, "ndi").putString(KEY_LAST_SOURCE, sourceName).apply();
        currentNdiSource = sourceName;
        statusText.setText(getString(R.string.connecting_to, sourceName));
        closeSourcePanel();
        showControls();
        if (activityVisible) startNdiPlayback();
    }

    private boolean hasSavedSource() {
        return htmlMode ? HtmlSourceUrl.isWebAddress(preferences.getString(KEY_HTML_URL, ""))
                : !currentNdiSource.isEmpty();
    }

    private void startNdiPlayback() {
        String source = currentNdiSource;
        receiverStats.reset();
        int generation = ++playbackGeneration;
        ndiPlaybackRequested = true;
        CAPTURE_WORKER.execute(() -> {
            if (!destroyed && activityVisible && !htmlMode && generation == playbackGeneration) {
                NdiReceiver.connect(source);
            }
        });
    }

    private void stopNdiPlayback() {
        ++playbackGeneration;
        if (ndiPlaybackRequested) {
            ndiPlaybackRequested = false;
            CAPTURE_WORKER.execute(NdiReceiver::disconnect);
        }
    }

    @SuppressWarnings("unused")
    public void onNativeStatus(String message) {
        runOnUiThread(() -> {
            if (!destroyed && activityVisible && !htmlMode) {
                statusText.setText(message);
                if (localControl != null && message != null && message.startsWith("Nao foi possivel criar"))
                    localControl.store.event("ndi_initialization_failure");
            }
        });
    }

    @SuppressWarnings("unused")
    public void onNativeVideoFormat(int width, int height, double fps) {
        runOnUiThread(() -> {
            if (destroyed || !activityVisible || htmlMode) return;
            sourceFps = fps;
            videoWidth = width;
            videoHeight = height;
            fitVideoSurface(width, height);
            statusText.setText(String.format(Locale.getDefault(), "%d x %d  •  %.2f fps", width, height, fps));
        });
    }


    @SuppressWarnings("unused")
    public void onNativePerformance(String source, long captured, long dropped, int queued) {
        runOnUiThread(() -> {
            if (!destroyed && activityVisible && !htmlMode && currentNdiSource.equals(source))
                receiverStats.accept(captured, dropped, queued, SystemClock.elapsedRealtime());
        });
    }

    private org.json.JSONObject localStatus() throws Exception {
        String selected = htmlMode ? preferences.getString(KEY_HTML_URL, "") : currentNdiSource;
        String label = selected;
        if (htmlMode) {
            try { java.net.URI uri = new java.net.URI(selected); label = uri.getHost() + uri.getPath(); }
            catch (Exception invalid) { label = "HTML"; }
            for (HtmlSource source : htmlSourceCatalog.snapshot()) if (source.url.equals(selected)) label = source.title;
        }
        org.json.JSONObject playback = htmlMode ? new org.json.JSONObject().put("state", htmlMonitor.state())
                : receiverStats.json(SystemClock.elapsedRealtime()).put("width", videoWidth)
                        .put("height", videoHeight).put("source_fps", sourceFps);
        return new org.json.JSONObject().put("mode", htmlMode ? "html" : "ndi")
                .put("source", label == null ? "" : label).put("playback", playback);
    }

    private org.json.JSONObject localSources() throws Exception {
        org.json.JSONArray sources = new org.json.JSONArray();
        for (HtmlSource source : htmlSourceCatalog.snapshot()) {
            if (sources.length() >= 80) break;
            sources.put(new org.json.JSONObject().put("mode", "html").put("name", source.title).put("url", source.url));
        }
        for (String name : displayedSources) {
            if (sources.length() >= 96) break;
            sources.put(new org.json.JSONObject().put("mode", "ndi").put("name", name));
        }
        return new org.json.JSONObject().put("sources", sources);
    }

    private void applyLocalCatalog(org.json.JSONObject command, boolean save) throws Exception {
        String origin;
        try { origin = SpresenterConnection.normalizeOrigin(command.getString("origin")); }
        catch (Exception invalid) { throw new LanControlServer.Failure(400); }
        org.json.JSONArray sources = command.getJSONArray("sources");
        if (sources.length() > 48) throw new LanControlServer.Failure(400);
        List<HtmlSource> list = new ArrayList<>();
        for (int i = 0; i < sources.length(); i++) {
            org.json.JSONObject source = sources.getJSONObject(i);
            String url = source.getString("url");
            java.net.URI uri = java.net.URI.create(url);
            if (!url.startsWith(origin + "/output/") || uri.getRawQuery() != null || uri.getRawFragment() != null
                    || !HtmlSourceUrl.isOutputPath(uri.getRawPath())) throw new LanControlServer.Failure(400);
            list.add(new HtmlSource(url, LocalControlStore.cleanName(source.optString("name")), origin));
        }
        htmlSourceCatalog.replacePinnedCatalog(origin, list, SystemClock.elapsedRealtime());
        if (save) {
            preferences.edit().putString("local_html_catalog", new org.json.JSONObject().put("origin", origin)
                    .put("sources", sources).toString()).apply();
            if (htmlMode) showHtmlSources();
        }
    }

    private org.json.JSONObject localCommand(org.json.JSONObject command) throws Exception {
        String action = command.optString("action");
        switch (action) {
            case "catalog":
                applyLocalCatalog(command, true);
                return new org.json.JSONObject().put("applied", true).put("outcome", "catalog_updated");
            case "set_source": {
                String mode = command.optString("mode");
                if ("html".equals(mode)) {
                    String url;
                    try { url = HtmlSourceUrl.normalize(command.getString("url")); }
                    catch (Exception invalid) { throw new LanControlServer.Failure(400); }
                    if (!htmlMode) {
                        preferences.edit().putString(KEY_HTML_URL, url).apply();
                        setSourceMode(true, false);
                    } else selectHtmlSource(url);
                } else if ("ndi".equals(mode)) {
                    String name = command.optString("name");
                    if (name.trim().isEmpty() || name.length() > 256 || name.matches("(?s).*[\\p{Cntrl}].*"))
                        throw new LanControlServer.Failure(400);
                    if (!NdiReceiver.isNdiAvailable()) throw new LanControlServer.Failure(409);
                    if (htmlMode) {
                        preferences.edit().putString(KEY_LAST_SOURCE, name).apply();
                        setSourceMode(false, false);
                    } else connectToSource(name);
                } else throw new LanControlServer.Failure(400);
                break;
            }
            case "reload_html":
                if (!htmlMode) throw new LanControlServer.Failure(409);
                htmlMonitor.reload(); break;
            case "reconnect_ndi":
                if (htmlMode || currentNdiSource.isEmpty()) throw new LanControlServer.Failure(409);
                stopNdiPlayback(); startNdiPlayback(); break;
            case "clear_html_cache":
                if (!htmlMode) throw new LanControlServer.Failure(409);
                htmlMonitor.clearResourceCache(); break;
            case "refresh_sources":
                discoveryRequested = true; scanSources();
                return new org.json.JSONObject().put("applied", true).put("outcome", "search_started");
            case "identify":
                android.widget.Toast.makeText(this, "S-Retorno — " + localControl.store.name(), android.widget.Toast.LENGTH_LONG).show();
                break;
            default: throw new LanControlServer.Failure(400);
        }
        localControl.store.event("maintenance_" + action);
        return new org.json.JSONObject().put("applied", true).put("outcome", "command_applied");
    }

    private void fitVideoSurface(int width, int height) {
        if (width <= 0 || height <= 0 || videoContainer.getWidth() == 0) return;
        int availableWidth = videoContainer.getWidth();
        int availableHeight = videoContainer.getHeight();
        float videoRatio = (float) width / height;
        float containerRatio = (float) availableWidth / availableHeight;
        int targetWidth;
        int targetHeight;
        if (videoRatio > containerRatio) {
            targetWidth = availableWidth;
            targetHeight = Math.round(availableWidth / videoRatio);
        } else {
            targetHeight = availableHeight;
            targetWidth = Math.round(availableHeight * videoRatio);
        }
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(targetWidth, targetHeight);
        params.gravity = android.view.Gravity.CENTER;
        videoSurface.setLayoutParams(params);
    }

    @SuppressWarnings("unused")
    public synchronized void onNativeAudio(short[] pcm, int sampleRate, int channels) {
        if (destroyed || htmlMode || !activityVisible || pcm == null || pcm.length == 0) return;
        if (audioTrack == null || audioSampleRate != sampleRate || audioChannels != channels) {
            configureAudio(sampleRate, channels);
        }
        if (audioTrack != null) {
            audioTrack.write(pcm, 0, pcm.length, AudioTrack.WRITE_NON_BLOCKING);
        }
    }

    private synchronized void configureAudio(int sampleRate, int channels) {
        releaseAudio();
        int channelMask = channels <= 1 ? AudioFormat.CHANNEL_OUT_MONO : AudioFormat.CHANNEL_OUT_STEREO;
        int minimum = AudioTrack.getMinBufferSize(sampleRate, channelMask, AudioFormat.ENCODING_PCM_16BIT);
        if (minimum <= 0) return;
        audioTrack = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                        .build())
                .setAudioFormat(new AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelMask)
                        .build())
                .setBufferSizeInBytes(minimum * 3)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
        audioTrack.play();
        audioSampleRate = sampleRate;
        audioChannels = channels;
    }

    private synchronized void releaseAudio() {
        if (audioTrack != null) {
            try {
                audioTrack.pause();
                audioTrack.flush();
                audioTrack.release();
            } catch (IllegalStateException ignored) {
            }
            audioTrack = null;
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        NdiReceiver.setSurface(holder.getSurface());
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        NdiReceiver.setSurface(holder.getSurface());
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        NdiReceiver.setSurface(null);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enterImmersiveMode();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        if (lanNetworkMonitor != null) lanNetworkMonitor.stop();
        if (localControl != null) localControl.close();
        stopSpresenterPairing();
        stopNdiPlayback();
        htmlMonitor.destroy();
        stopDiscoveryPolling();
        controlsHandler.removeCallbacksAndMessages(null);
        if (settingsDialog != null) settingsDialog.dismiss();
        if (noticesDialog != null) noticesDialog.dismiss();
        if (modeDialog != null) modeDialog.dismiss();
        if (htmlAddressDialog != null) htmlAddressDialog.dismiss();
        if (htmlLayoutDialog != null) htmlLayoutDialog.dismiss();
        if (spresenterDialog != null) spresenterDialog.dismiss();
        BackNavigation.unregister(this, backCallback);
        NdiReceiver.setCallbackTarget(null);
        releaseAudio();
        if (multicastLock != null && multicastLock.isHeld()) multicastLock.release();
        super.onDestroy();
    }
}
