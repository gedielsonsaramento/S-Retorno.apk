# S-Retorno 1.5.2 + Central de Retornos 0.1.2

Projeto corrigido e compilado em 31/10/2026. Comece pelo teste na box utilizada em HTML.

## Atualizar

1. Na box, instale **Instaladores/S-Retorno-1.5.2.apk** sobre a versão anterior, sem desinstalar. O pacote e o certificado são os mesmos da edição TVBox 1.5.1, preservando suas configurações.
2. No Spresenter, vá a **Configurações → Plugins → Instalar (.zip/pasta)** e selecione **Instaladores/S-Retorno-Central-0.1.2.zip**. Selecione esse ZIP específico, não o ZIP do projeto completo.
3. Abra **Central de Retornos** no Spresenter. Para novo vínculo, abra na box **Engrenagem → Central de Retornos → Gerar código de pareamento**, mantenha a janela aberta e informe no plugin o endereço completo mostrado, com a porta, e o código.
4. Em **Fontes do Spresenter**, cole o link de **Editor remoto (rede) → Copiar link com token**. O plugin informa a consulta e a resposta. Após o vínculo, escolha a fonte em cada cartão do retorno.

A porta de gerenciamento da box é **48762**. As saídas HTML do PC normalmente usam **5050**; use sempre a porta efetivamente mostrada no respectivo programa.

## Correções

- A Central mostra tentativa, progresso, conclusão e erro. Mensagens de pareamento aparecem dentro da janela aberta. A ponte aceita o envelope oficial inclusive quando o relay não preenche a origem da mensagem.
- O app busca novos endereços ao trocar de rede e ao abrir a lista HTML, sem exigir a exclusão dos PCs antigos nem trocar a fonte selecionada. A busca automática é pública; use **↻** para consultar também os catálogos autorizados.
- É possível manter até oito PCs, cada um com sua chave. A busca opcional em outra faixa aceita, por exemplo, **192.168.2**. Os roteadores precisam permitir a comunicação entre as faixas.
- O nome foi corrigido para **Spresenter** nas interfaces.
- O APK volta a incluir o JavaScript/CSS de compatibilidade para motores antigos. Esses arquivos estavam ausentes no APK 1.5.1 e podem explicar o texto comprimido fotografado. O perfil confere os arquivos do servidor antes de adaptar; versões diferentes do Spresenter podem exigir outra captura.
- Diagnósticos e relatórios técnicos saíram da interface da box; registros e métricas internos continuam disponíveis na Central. Desligar os aparelhos após o culto permanece **Sem comunicação**, sem criar falha automática.

## Conteúdo

- **Instaladores/**: APK Android e ZIP instalável do plugin.
- **Fontes/S-Retorno-1.5.2/**: projeto Android completo, fontes e empacotador do plugin, testes, documentação, perfil HTML e runtime nativo para recompilar Java/interface.
- **VALIDACAO.json** e **VERSOES.json**: resultados, versões e hashes.

Para recompilar, abra a pasta que contém `settings.gradle` e siga **docs/COMPILAR_1.5.2.md**. Use JDK 17 e SDK Android 36. O comando é `./gradlew :app:assembleTvboxTest -PmonitorPrebuiltNativeDir=../local-native` (no Windows, `gradlew.bat`). O APK pronto conserva a assinatura anterior; recompilações em outro ambiente precisam da chave original para atualizar instalações existentes. A chave privada e o instalador do SDK NDI ficam separados da entrega.

## Testes e conferência na box

Passaram 281 testes Android, 14 testes do plugin, lint sem erros e a compilação TVBox. O plugin também foi testado em navegador com o servidor Java real: código inválido/válido, localização, catálogo e comandos. O perfil HTML preservou o tema 1920 × 1080 e a largura da letra nos testes de navegador e atualizou por WebSocket.

Ainda é necessário conferir a disposição mostrada na foto no WebView físico da sua box e as ações dentro do Spresenter instalado. Troque de rede sem apagar os PCs anteriores, selecione o novo endereço e teste a atualização das letras. Repita o ciclo de desligar e ligar os aparelhos usado na igreja. O resultado detalhado está em **docs/historico/VALIDACAO_1.5.2.md**.
