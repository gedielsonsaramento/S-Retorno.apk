# S-Retorno 1.5.5 — Fluidez RC1

Revisão candidata para teste em TV boxes, baseada na correção HTML HF1.
A recepção NDI tem uma fila limitada de vídeo e uma fila própria para o áudio.

## HTML mais leve

Na engrenagem, abra **Exibição HTML** e selecione **Monitor 16:9 — leve (720p, menor resolução)**.
O conteúdo mantém a proporção de 16:9. Essa opção pode reduzir a nitidez; as opções anteriores continuam disponíveis.
A escolha fica salva após fechar o app ou desligar a box.

## Compilar

Abra esta pasta no Android Studio. Use JDK 17 ou 21, SDK Android 36,
NDK 28.2.13676358 e CMake 3.22.1. O SDK NDI fornecido para ARM32 e ARM64 está incluído.
Escolha a variante **tvboxTest** e gere o APK, ou execute:

```sh
./gradlew :app:assembleTvboxTest
```

No Windows, use `gradlew.bat :app:assembleTvboxTest`.
O resultado fica em `app/build/outputs/apk/tvboxTest/`.
Recompilar C++ é obrigatório: `monitorPrebuiltNativeDir` é rejeitado nesta revisão.

A assinatura de uma compilação local precisa corresponder à instalada para atualizar sem desinstalar.
Nenhuma chave privada é incluída neste projeto.

## Central de Retornos 0.1.5

O plugin mostra novas métricas NDI nos detalhes de cada box: captura, envio à tela,
quadros substituídos antes do desenho, tempo de desenho e fila/falhas do áudio.
O desligamento diário continua sendo tratado como ausência neutra.

Consulte **REVISAO_FLUIDEZ.md** para mudanças e limitações. A validação na box real
é necessária; testes de código não garantem ausência de engasgos em qualquer rede ou equipamento.

## Resultado desta candidata

APK compilado, assinatura verificada, 42 testes do app e 24 do painel aprovados.
Veja **VALIDACAO_1.5.5.md** para escopo dos testes e roteiro de verificação na box.
